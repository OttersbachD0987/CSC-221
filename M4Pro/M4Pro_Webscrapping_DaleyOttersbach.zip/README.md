# Report

I chose to do all three of the extensions.
The only real difficulties I encountered where when I forgot to format the URL properly so it wasn't replacing the value, and as such always returned an error.
I learned how to use the pandas library with matplotlib.
