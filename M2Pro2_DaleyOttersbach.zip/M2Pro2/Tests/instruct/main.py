import csv

for i in range(4):
    print(f"{i}: i")

a = input("Bokn: ")

print(" M  ")

print(a)

print(" M  ")

b = input("NB: ")

print(" V  ")

print(b + a)

print(" V  ")

x = False

while x:
    ...

while True:
    break