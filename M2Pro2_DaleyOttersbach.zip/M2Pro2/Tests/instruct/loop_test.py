def bunk() -> bool:
    return True

while True:
    ...

while not False:
    ...

while 1 == 1:
    ...

while len("25") > 0:
    ...


while bunk():
    ...